#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import os
import urllib.parse
import datetime

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:

    ALLOWED_IPS = []    # IP白名单





